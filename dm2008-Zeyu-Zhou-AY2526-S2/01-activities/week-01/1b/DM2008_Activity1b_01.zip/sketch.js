// DM2008
// Activity 1b (Ryoji Ikeda)

let x;
let w;

function setup() {
  createCanvas(800, 800);
  background(255);
  noStroke();
  fill(0);
}

function draw() {
  background(255, 10);
  
  //top left
  fill(255, 40, 0);
  x = random(mouseX);
  w = random(1, 10);
  h = mouseY;
  rect(x, 0, w, h);
  
  //top right
  fill(255, 144, 0);
  x = random(mouseX, width);
  w = random(1, 10);
  h = mouseY;
  rect(x, 0, w, h);
  
  //btm left
  fill(0, 255, 230);
  x = random(mouseX);
  w = random(1, 10)
  h = height - mouseY;
  rect(x, mouseY, w, h);
  
  //btm right
  fill(0, 153, 255);
  x = random(mouseX, width);
  w = random(1, 10)
  h = height - mouseY;
  rect(x, mouseY, w, h);
}

function keyPressed() {
  saveCanvas("activity1b-image", "jpg");
}