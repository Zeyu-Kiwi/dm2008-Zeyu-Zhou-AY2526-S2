// DDM2008
// Activity 1a

// Run the sketch, then click on the preview to enable keyboard
// Use the 'Option' ('Alt' on Windows) key to view or hide the grid
// Use the 'Shift' key to change overlays between black & white
// Write the code for your creature in the space provided

function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(240);
  
  //rect_head
  fill(255, 178, 102);
  noStroke();
  rect(150, 150, 50, 50);
  
  //triangle_ear_L
  triangle(150, 150, 
           150, 125, 
           170, 150);
  
  //triangle_ear_R
  triangle(180, 150, 
           200, 125, 
           200, 150);
  
  //quad_body
  quad(150, 300, 
       160, 200, 
       190, 200, 
       200, 300);
  
  //stroke_tail_001
  strokeWeight(8);
  stroke(255, 178, 102);
  line(195, 296, 225, 296);
  line(225, 296, 225, 225);
  line(225, 225, 260, 225);
  line(260, 225, 260, 225);
  line(260, 225, 260, 255);
  line(260, 255, 240, 255);
  line(240, 255, 240, 240);
  
  helperGrid(); // do not edit or remove this line
}
